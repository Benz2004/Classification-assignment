## =========================================================
## Logistic Regression with:
## - Train/Test split
## - 5-fold stratified CV
## - Baseline vs Improved logistic
## - Confusion matrix, Precision, Recall, ROC, AUC
## =========================================================

set.seed(123)

## 1. Load data
url <- "https://www.maths.dur.ac.uk/users/hailiang.du/assignment_data/bank_personal_loan.csv"
bank <- read.csv(url, stringsAsFactors = FALSE)

## 2. Preprocessing
bank$Experience[bank$Experience < 0] <- 0
bank$ZIP.Code <- NULL

bank$Personal.Loan <- factor(bank$Personal.Loan, levels = c(0, 1), labels = c("No", "Yes"))
bank$Securities.Account <- factor(bank$Securities.Account, levels = c(0, 1), labels = c("No", "Yes"))
bank$CD.Account <- factor(bank$CD.Account, levels = c(0, 1), labels = c("No", "Yes"))
bank$Online <- factor(bank$Online, levels = c(0, 1), labels = c("No", "Yes"))
bank$CreditCard <- factor(bank$CreditCard, levels = c(0, 1), labels = c("No", "Yes"))

bank$Education <- factor(
  bank$Education,
  levels = c(1, 2, 3),
  labels = c("Undergraduate", "Graduate", "Advanced/Professional")
)

## 3. Stratified train/test split
stratified_split <- function(y, train_prop = 0.7, seed = 123) {
  set.seed(seed)
  idx_yes <- which(y == "Yes")
  idx_no  <- which(y == "No")
  
  train_yes <- sample(idx_yes, size = floor(train_prop * length(idx_yes)))
  train_no  <- sample(idx_no,  size = floor(train_prop * length(idx_no)))
  
  train_idx <- sort(c(train_yes, train_no))
  test_idx  <- setdiff(seq_along(y), train_idx)
  
  list(train_idx = train_idx, test_idx = test_idx)
}

split_obj <- stratified_split(bank$Personal.Loan, train_prop = 0.7, seed = 123)
train <- bank[split_obj$train_idx, ]
test  <- bank[split_obj$test_idx, ]

cat("Training set size:", nrow(train), "\n")
cat("Test set size:", nrow(test), "\n\n")

cat("Training target proportions:\n")
print(round(prop.table(table(train$Personal.Loan)), 4))
cat("\n")

cat("Test target proportions:\n")
print(round(prop.table(table(test$Personal.Loan)), 4))
cat("\n")

## 4. Stratified K-fold creation
make_stratified_folds <- function(y, k = 5, seed = 123) {
  set.seed(seed)
  
  idx_yes <- sample(which(y == "Yes"))
  idx_no  <- sample(which(y == "No"))
  
  split_yes <- split(idx_yes, rep(1:k, length.out = length(idx_yes)))
  split_no  <- split(idx_no,  rep(1:k, length.out = length(idx_no)))
  
  folds <- vector("list", k)
  for (i in 1:k) {
    folds[[i]] <- sort(c(split_yes[[i]], split_no[[i]]))
  }
  folds
}

folds <- make_stratified_folds(train$Personal.Loan, k = 5, seed = 123)

## 5. Helper functions

log_loss <- function(y_true_factor, p_hat, eps = 1e-15) {
  y_true <- ifelse(y_true_factor == "Yes", 1, 0)
  p_hat <- pmin(pmax(p_hat, eps), 1 - eps)
  -mean(y_true * log(p_hat) + (1 - y_true) * log(1 - p_hat))
}

classification_metrics <- function(y_true_factor, p_hat, threshold = 0.5) {
  pred_class <- ifelse(p_hat >= threshold, "Yes", "No")
  pred_class <- factor(pred_class, levels = c("No", "Yes"))
  
  cm <- table(Predicted = pred_class, Actual = y_true_factor)
  
  ## force full 2x2 structure
  all_levels <- c("No", "Yes")
  full_cm <- matrix(0, nrow = 2, ncol = 2,
                    dimnames = list(Predicted = all_levels, Actual = all_levels))
  full_cm[rownames(cm), colnames(cm)] <- cm
  cm <- full_cm
  
  TN <- cm["No",  "No"]
  FN <- cm["No",  "Yes"]
  FP <- cm["Yes", "No"]
  TP <- cm["Yes", "Yes"]
  
  accuracy <- (TP + TN) / sum(cm)
  recall <- ifelse((TP + FN) == 0, NA, TP / (TP + FN))          # sensitivity
  specificity <- ifelse((TN + FP) == 0, NA, TN / (TN + FP))
  precision <- ifelse((TP + FP) == 0, NA, TP / (TP + FP))
  f1 <- ifelse(is.na(precision) || is.na(recall) || (precision + recall) == 0,
               NA, 2 * precision * recall / (precision + recall))
  balanced_accuracy <- mean(c(recall, specificity), na.rm = TRUE)
  
  data.frame(
    Accuracy = accuracy,
    Precision = precision,
    Recall = recall,
    Specificity = specificity,
    F1 = f1,
    Balanced_Accuracy = balanced_accuracy,
    LogLoss = log_loss(y_true_factor, p_hat)
  ) -> out
  
  attr(out, "confusion_matrix") <- cm
  out
}

## AUC using rank-sum / Mann-Whitney formulation
auc_manual <- function(y_true_factor, p_hat) {
  y_true <- ifelse(y_true_factor == "Yes", 1, 0)
  
  n_pos <- sum(y_true == 1)
  n_neg <- sum(y_true == 0)
  
  if (n_pos == 0 || n_neg == 0) return(NA_real_)
  
  ranks <- rank(p_hat, ties.method = "average")
  sum_ranks_pos <- sum(ranks[y_true == 1])
  
  auc <- (sum_ranks_pos - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)
  auc
}

## ROC points for plotting
roc_curve_manual <- function(y_true_factor, p_hat) {
  y_true <- ifelse(y_true_factor == "Yes", 1, 0)
  
  thresholds <- sort(unique(p_hat), decreasing = TRUE)
  thresholds <- c(Inf, thresholds, -Inf)
  
  tpr <- numeric(length(thresholds))
  fpr <- numeric(length(thresholds))
  
  for (i in seq_along(thresholds)) {
    pred <- ifelse(p_hat >= thresholds[i], 1, 0)
    
    TP <- sum(pred == 1 & y_true == 1)
    FP <- sum(pred == 1 & y_true == 0)
    TN <- sum(pred == 0 & y_true == 0)
    FN <- sum(pred == 0 & y_true == 1)
    
    tpr[i] <- ifelse((TP + FN) == 0, 0, TP / (TP + FN))
    fpr[i] <- ifelse((FP + TN) == 0, 0, FP / (FP + TN))
  }
  
  data.frame(FPR = fpr, TPR = tpr, Threshold = thresholds)
}

## 6. Define models
formula_base <- Personal.Loan ~ Age + Experience + Income + Family +
  CCAvg + Education + Mortgage +
  Securities.Account + CD.Account + Online + CreditCard

formula_improved <- Personal.Loan ~ Age + Experience +
  Income + I(Income^2) +
  CCAvg + I(CCAvg^2) +
  Income:CCAvg +
  Family + Education + Mortgage +
  Securities.Account + CD.Account + Online + CreditCard

## 7. 5-fold CV on training data
cv_results <- data.frame(
  Model = character(),
  Fold = integer(),
  Accuracy = numeric(),
  Precision = numeric(),
  Recall = numeric(),
  Specificity = numeric(),
  F1 = numeric(),
  Balanced_Accuracy = numeric(),
  LogLoss = numeric(),
  AUC = numeric(),
  stringsAsFactors = FALSE
)

for (i in 1:5) {
  valid_idx <- folds[[i]]
  cv_valid <- train[valid_idx, ]
  cv_train <- train[-valid_idx, ]
  
  ## Baseline model
  m_base <- glm(formula_base, data = cv_train, family = binomial(link = "logit"))
  p_base <- predict(m_base, newdata = cv_valid, type = "response")
  met_base <- classification_metrics(cv_valid$Personal.Loan, p_base, threshold = 0.5)
  
  cv_results <- rbind(
    cv_results,
    data.frame(
      Model = "Baseline",
      Fold = i,
      Accuracy = met_base$Accuracy,
      Precision = met_base$Precision,
      Recall = met_base$Recall,
      Specificity = met_base$Specificity,
      F1 = met_base$F1,
      Balanced_Accuracy = met_base$Balanced_Accuracy,
      LogLoss = met_base$LogLoss,
      AUC = auc_manual(cv_valid$Personal.Loan, p_base)
    )
  )
  
  ## Improved model
  m_improved <- glm(formula_improved, data = cv_train, family = binomial(link = "logit"))
  p_improved <- predict(m_improved, newdata = cv_valid, type = "response")
  met_improved <- classification_metrics(cv_valid$Personal.Loan, p_improved, threshold = 0.5)
  
  cv_results <- rbind(
    cv_results,
    data.frame(
      Model = "Improved",
      Fold = i,
      Accuracy = met_improved$Accuracy,
      Precision = met_improved$Precision,
      Recall = met_improved$Recall,
      Specificity = met_improved$Specificity,
      F1 = met_improved$F1,
      Balanced_Accuracy = met_improved$Balanced_Accuracy,
      LogLoss = met_improved$LogLoss,
      AUC = auc_manual(cv_valid$Personal.Loan, p_improved)
    )
  )
}

cat("Cross-validation results by fold:\n")
print(cv_results)
cat("\n")

cv_summary <- aggregate(
  cbind(Accuracy, Precision, Recall, Specificity, F1,
        Balanced_Accuracy, LogLoss, AUC) ~ Model,
  data = cv_results,
  FUN = mean,
  na.rm = TRUE
)

cat("Mean CV results:\n")
print(cv_summary)
cat("\n")

## 8. Choose best model
best_model_name <- cv_summary$Model[which.min(cv_summary$LogLoss)]
cat("Best model selected by CV LogLoss:", best_model_name, "\n\n")

## 9. Fit chosen model on full training set
if (best_model_name == "Baseline") {
  final_model <- glm(formula_base, data = train, family = binomial(link = "logit"))
} else {
  final_model <- glm(formula_improved, data = train, family = binomial(link = "logit"))
}

cat("Final model summary:\n")
print(summary(final_model))
cat("\n")

## 10. Evaluate on test set
test_prob <- predict(final_model, newdata = test, type = "response")
test_metrics <- classification_metrics(test$Personal.Loan, test_prob, threshold = 0.5)
test_auc <- auc_manual(test$Personal.Loan, test_prob)

cat("Test confusion matrix:\n")
print(attr(test_metrics, "confusion_matrix"))
cat("\n")

cat("Test set metrics:\n")
test_results <- data.frame(
  Accuracy = test_metrics$Accuracy,
  Precision = test_metrics$Precision,
  Recall = test_metrics$Recall,
  Specificity = test_metrics$Specificity,
  F1 = test_metrics$F1,
  Balanced_Accuracy = test_metrics$Balanced_Accuracy,
  LogLoss = test_metrics$LogLoss,
  AUC = test_auc
)
print(test_results)
cat("\n")

## 11. Save outputs and plots
if (!dir.exists("outputs")) dir.create("outputs")

write.csv(cv_results, "outputs/logistic_cv_results.csv", row.names = FALSE)
write.csv(cv_summary, "outputs/logistic_cv_summary.csv", row.names = FALSE)
write.csv(test_results, "outputs/logistic_test_results.csv", row.names = FALSE)
write.csv(threshold_results, "outputs/logistic_threshold_results.csv", row.names = FALSE)

pred_out <- data.frame(
  Actual = test$Personal.Loan,
  Predicted_Prob_Yes = test_prob,
  Predicted_Class_0.5 = ifelse(test_prob >= 0.5, "Yes", "No")
)
write.csv(pred_out, "outputs/logistic_test_predictions.csv", row.names = FALSE)

## ROC plot
roc_df <- roc_curve_manual(test$Personal.Loan, test_prob)

png("outputs/logistic_test_roc_curve.png", width = 800, height = 600)
plot(
  roc_df$FPR, roc_df$TPR,
  type = "l", lwd = 2,
  xlab = "False Positive Rate",
  ylab = "True Positive Rate",
  main = paste("ROC Curve (AUC =", round(test_auc, 4), ")")
)
abline(a = 0, b = 1, lty = 2)
dev.off()

## Predicted probability histogram
png("outputs/logistic_predicted_probabilities.png", width = 800, height = 600)
hist(
  test_prob,
  breaks = 30,
  main = "Predicted Probabilities on Test Set",
  xlab = "Predicted P(Personal.Loan = Yes)",
  col = "grey80",
  border = "white"
)
dev.off()

## Predicted probability by actual class
png("outputs/logistic_prob_by_actual_class.png", width = 800, height = 600)
boxplot(
  test_prob ~ test$Personal.Loan,
  main = "Predicted Probability by Actual Class",
  xlab = "Actual Class",
  ylab = "Predicted Probability of Yes",
  col = c("grey80", "lightblue")
)
dev.off()

cat("Done. Outputs saved in the 'outputs' folder.\n")