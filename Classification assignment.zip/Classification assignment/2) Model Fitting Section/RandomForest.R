## =========================================================
## Random Forest (lecture-aligned version)
## - Train/Test split
## - OOB tuning for mtry
## - Final test-set evaluation
## - Confusion matrix, Precision, Recall, ROC, AUC
## =========================================================

set.seed(123)

## 1. Load required package
if (!requireNamespace("randomForest", quietly = TRUE)) {
  stop("Package 'randomForest' is required but not installed.")
}
library(randomForest)

## 2. Load data
url <- "https://www.maths.dur.ac.uk/users/hailiang.du/assignment_data/bank_personal_loan.csv"
bank <- read.csv(url, stringsAsFactors = FALSE)

## 3. Preprocessing
bank$Experience[bank$Experience < 0] <- 0
bank$ZIP.Code <- NULL

bank$Personal.Loan <- factor(bank$Personal.Loan, levels = c(0, 1), labels = c("No", "Yes"))
bank$Securities.Account <- factor(bank$Securities.Account, levels = c(0, 1), labels = c("No", "Yes"))
bank$CD.Account <- factor(bank$CD.Account, levels = c(0, 1), labels = c("No", "Yes"))
bank$Online <- factor(bank$Online, levels = c(0, 1), labels = c("No", "Yes"))
bank$CreditCard <- factor(bank$CreditCard, levels = c(0, 1), labels = c("No", "Yes"))

bank$Education <- factor(
  bank$Education,
  levels = c(1, 2, 3),
  labels = c("Undergraduate", "Graduate", "Advanced/Professional")
)

## 4. Stratified train/test split
stratified_split <- function(y, train_prop = 0.7, seed = 123) {
  set.seed(seed)
  idx_yes <- which(y == "Yes")
  idx_no  <- which(y == "No")
  
  train_yes <- sample(idx_yes, size = floor(train_prop * length(idx_yes)))
  train_no  <- sample(idx_no,  size = floor(train_prop * length(idx_no)))
  
  train_idx <- sort(c(train_yes, train_no))
  test_idx  <- setdiff(seq_along(y), train_idx)
  
  list(train_idx = train_idx, test_idx = test_idx)
}

split_obj <- stratified_split(bank$Personal.Loan, train_prop = 0.7, seed = 123)
train <- bank[split_obj$train_idx, ]
test  <- bank[split_obj$test_idx, ]

cat("Training set size:", nrow(train), "\n")
cat("Test set size:", nrow(test), "\n\n")

cat("Training target proportions:\n")
print(round(prop.table(table(train$Personal.Loan)), 4))
cat("\n")

cat("Test target proportions:\n")
print(round(prop.table(table(test$Personal.Loan)), 4))
cat("\n")

## 5. Helper functions
log_loss <- function(y_true_factor, p_hat, eps = 1e-15) {
  y_true <- ifelse(y_true_factor == "Yes", 1, 0)
  p_hat <- pmin(pmax(p_hat, eps), 1 - eps)
  -mean(y_true * log(p_hat) + (1 - y_true) * log(1 - p_hat))
}

classification_metrics <- function(y_true_factor, p_hat, threshold = 0.5) {
  pred_class <- ifelse(p_hat >= threshold, "Yes", "No")
  pred_class <- factor(pred_class, levels = c("No", "Yes"))
  
  cm <- table(Predicted = pred_class, Actual = y_true_factor)
  
  all_levels <- c("No", "Yes")
  full_cm <- matrix(0, nrow = 2, ncol = 2,
                    dimnames = list(Predicted = all_levels, Actual = all_levels))
  full_cm[rownames(cm), colnames(cm)] <- cm
  cm <- full_cm
  
  TN <- cm["No",  "No"]
  FN <- cm["No",  "Yes"]
  FP <- cm["Yes", "No"]
  TP <- cm["Yes", "Yes"]
  
  accuracy <- (TP + TN) / sum(cm)
  recall <- ifelse((TP + FN) == 0, NA, TP / (TP + FN))
  specificity <- ifelse((TN + FP) == 0, NA, TN / (TN + FP))
  precision <- ifelse((TP + FP) == 0, NA, TP / (TP + FP))
  f1 <- ifelse(is.na(precision) || is.na(recall) || (precision + recall) == 0,
               NA, 2 * precision * recall / (precision + recall))
  balanced_accuracy <- mean(c(recall, specificity), na.rm = TRUE)
  
  out <- data.frame(
    Accuracy = accuracy,
    Precision = precision,
    Recall = recall,
    Specificity = specificity,
    F1 = f1,
    Balanced_Accuracy = balanced_accuracy,
    LogLoss = log_loss(y_true_factor, p_hat)
  )
  
  attr(out, "confusion_matrix") <- cm
  out
}

auc_manual <- function(y_true_factor, p_hat) {
  y_true <- ifelse(y_true_factor == "Yes", 1, 0)
  
  n_pos <- sum(y_true == 1)
  n_neg <- sum(y_true == 0)
  
  if (n_pos == 0 || n_neg == 0) return(NA_real_)
  
  ranks <- rank(p_hat, ties.method = "average")
  sum_ranks_pos <- sum(ranks[y_true == 1])
  
  (sum_ranks_pos - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)
}

roc_curve_manual <- function(y_true_factor, p_hat) {
  y_true <- ifelse(y_true_factor == "Yes", 1, 0)
  
  thresholds <- sort(unique(p_hat), decreasing = TRUE)
  thresholds <- c(Inf, thresholds, -Inf)
  
  tpr <- numeric(length(thresholds))
  fpr <- numeric(length(thresholds))
  
  for (i in seq_along(thresholds)) {
    pred <- ifelse(p_hat >= thresholds[i], 1, 0)
    
    TP <- sum(pred == 1 & y_true == 1)
    FP <- sum(pred == 1 & y_true == 0)
    TN <- sum(pred == 0 & y_true == 0)
    FN <- sum(pred == 0 & y_true == 1)
    
    tpr[i] <- ifelse((TP + FN) == 0, 0, TP / (TP + FN))
    fpr[i] <- ifelse((FP + TN) == 0, 0, FP / (FP + TN))
  }
  
  data.frame(FPR = fpr, TPR = tpr, Threshold = thresholds)
}

## 6. Model formula
rf_formula <- Personal.Loan ~ Age + Experience + Income + Family +
  CCAvg + Education + Mortgage +
  Securities.Account + CD.Account + Online + CreditCard

## 7. OOB tuning over mtry
## Lecture emphasis: random subspace size m is the key RF choice
p <- ncol(train) - 1
mtry_grid <- unique(pmax(1, c(floor(sqrt(p)), floor(p/3), floor(p/2), p)))
mtry_grid <- sort(unique(mtry_grid))

ntree_value <- 1000

oob_results <- data.frame(
  mtry = integer(),
  OOB_Error = numeric()
)

rf_models <- vector("list", length(mtry_grid))

for (i in seq_along(mtry_grid)) {
  current_mtry <- mtry_grid[i]
  
  rf_fit <- randomForest(
    formula = rf_formula,
    data = train,
    ntree = ntree_value,
    mtry = current_mtry,
    importance = TRUE,
    keep.forest = TRUE
  )
  
  rf_models[[i]] <- rf_fit
  
  ## final OOB error from last tree
  final_oob_error <- rf_fit$err.rate[ntree_value, "OOB"]
  
  oob_results <- rbind(
    oob_results,
    data.frame(
      mtry = current_mtry,
      OOB_Error = final_oob_error
    )
  )
}

cat("OOB tuning results:\n")
print(oob_results)
cat("\n")

best_idx <- which.min(oob_results$OOB_Error)
best_mtry <- oob_results$mtry[best_idx]

cat("Selected mtry by minimum OOB error:", best_mtry, "\n")
cat("Number of trees:", ntree_value, "\n\n")

## 8. Refit final forest on full training set with chosen mtry
final_rf <- randomForest(
  formula = rf_formula,
  data = train,
  ntree = ntree_value,
  mtry = best_mtry,
  importance = TRUE,
  keep.forest = TRUE
)

print(final_rf)
cat("\n")

## 9. Evaluate on held-out test set
## Use class probabilities, not just vote proportions
test_prob_mat <- predict(final_rf, newdata = test, type = "prob")
test_prob <- test_prob_mat[, "Yes"]

test_metrics <- classification_metrics(test$Personal.Loan, test_prob, threshold = 0.5)
test_auc <- auc_manual(test$Personal.Loan, test_prob)

cat("Test confusion matrix:\n")
print(attr(test_metrics, "confusion_matrix"))
cat("\n")

test_results <- data.frame(
  Accuracy = test_metrics$Accuracy,
  Precision = test_metrics$Precision,
  Recall = test_metrics$Recall,
  Specificity = test_metrics$Specificity,
  F1 = test_metrics$F1,
  Balanced_Accuracy = test_metrics$Balanced_Accuracy,
  LogLoss = test_metrics$LogLoss,
  AUC = test_auc
)

cat("Test set metrics:\n")
print(test_results)
cat("\n")

## 10. Threshold comparison on test set
thresholds <- seq(0.1, 0.9, by = 0.1)
threshold_results <- data.frame(
  Threshold = numeric(),
  Accuracy = numeric(),
  Precision = numeric(),
  Recall = numeric(),
  Specificity = numeric(),
  F1 = numeric(),
  Balanced_Accuracy = numeric()
)

for (th in thresholds) {
  met <- classification_metrics(test$Personal.Loan, test_prob, threshold = th)
  threshold_results <- rbind(
    threshold_results,
    data.frame(
      Threshold = th,
      Accuracy = met$Accuracy,
      Precision = met$Precision,
      Recall = met$Recall,
      Specificity = met$Specificity,
      F1 = met$F1,
      Balanced_Accuracy = met$Balanced_Accuracy
    )
  )
}

cat("Threshold comparison on test set:\n")
print(threshold_results)
cat("\n")

## 11. Variable importance
cat("Variable importance:\n")
print(importance(final_rf))
cat("\n")

## 12. Save outputs and plots
if (!dir.exists("outputs")) dir.create("outputs")

write.csv(oob_results, "outputs/rf_oob_tuning_results.csv", row.names = FALSE)
write.csv(test_results, "outputs/rf_test_results.csv", row.names = FALSE)
write.csv(threshold_results, "outputs/rf_threshold_results.csv", row.names = FALSE)

importance_df <- as.data.frame(importance(final_rf))
importance_df$Variable <- rownames(importance_df)
write.csv(importance_df, "outputs/rf_variable_importance.csv", row.names = FALSE)

pred_out <- data.frame(
  Actual = test$Personal.Loan,
  Predicted_Prob_Yes = test_prob,
  Predicted_Class_0.5 = ifelse(test_prob >= 0.5, "Yes", "No")
)
write.csv(pred_out, "outputs/rf_test_predictions.csv", row.names = FALSE)

## OOB tuning plot
png("outputs/rf_oob_tuning_plot.png", width = 800, height = 600)
plot(
  oob_results$mtry, oob_results$OOB_Error,
  type = "b", pch = 19,
  xlab = "mtry",
  ylab = "OOB Error",
  main = "Random Forest OOB Error by mtry"
)
dev.off()

## OOB error vs number of trees
png("outputs/rf_oob_error_curve.png", width = 800, height = 600)
plot(
  final_rf$err.rate[, "OOB"],
  type = "l", lwd = 2,
  xlab = "Number of Trees",
  ylab = "OOB Error",
  main = "Random Forest OOB Error Curve"
)
dev.off()

## ROC plot
roc_df <- roc_curve_manual(test$Personal.Loan, test_prob)

png("outputs/rf_test_roc_curve.png", width = 800, height = 600)
plot(
  roc_df$FPR, roc_df$TPR,
  type = "l", lwd = 2,
  xlab = "False Positive Rate",
  ylab = "True Positive Rate",
  main = paste("Random Forest ROC Curve (AUC =", round(test_auc, 4), ")")
)
abline(a = 0, b = 1, lty = 2)
dev.off()

## Probability histogram
png("outputs/rf_predicted_probabilities.png", width = 800, height = 600)
hist(
  test_prob,
  breaks = 30,
  main = "Random Forest Predicted Probabilities",
  xlab = "Predicted P(Personal.Loan = Yes)",
  col = "grey80",
  border = "white"
)
dev.off()

## Probability by actual class
png("outputs/rf_prob_by_actual_class.png", width = 800, height = 600)
boxplot(
  test_prob ~ test$Personal.Loan,
  main = "Random Forest Probability by Actual Class",
  xlab = "Actual Class",
  ylab = "Predicted Probability of Yes",
  col = c("grey80", "lightblue")
)
dev.off()

## Variable importance plot
png("outputs/rf_variable_importance_plot.png", width = 1000, height = 700)
varImpPlot(final_rf, main = "Random Forest Variable Importance")
dev.off()

cat("Done. Random Forest tuned using OOB error and evaluated on the test set.\n")