## =========================
## Initial data summary
## =========================

set.seed(123)

## 1. Load data
url <- "https://www.maths.dur.ac.uk/users/hailiang.du/assignment_data/bank_personal_loan.csv"
bank <- read.csv(url, stringsAsFactors = FALSE)

## 2. Check structure
str(bank)
dim(bank)
names(bank)

## 3. Convert appropriate variables to factors
bank$Personal.Loan      <- factor(bank$Personal.Loan, levels = c(0, 1), labels = c("No", "Yes"))
bank$Securities.Account <- factor(bank$Securities.Account, levels = c(0, 1), labels = c("No", "Yes"))
bank$CD.Account         <- factor(bank$CD.Account, levels = c(0, 1), labels = c("No", "Yes"))
bank$Online             <- factor(bank$Online, levels = c(0, 1), labels = c("No", "Yes"))
bank$CreditCard         <- factor(bank$CreditCard, levels = c(0, 1), labels = c("No", "Yes"))

## Education is ordinal
bank$Education <- factor(
  bank$Education,
  levels = c(1, 2, 3),
  labels = c("Undergraduate", "Graduate", "Advanced/Professional"),
  ordered = TRUE
)

## ZIP code is categorical/identifier rather than continuous numeric
bank$ZIP.Code <- factor(bank$ZIP.Code)

## 4. Basic summary (used)
cat("Number of rows:", nrow(bank), "\n")
cat("Number of columns:", ncol(bank), "\n\n")

cat("Column names:\n")
print(names(bank))
cat("\n")

cat("Summary of data:\n")
print(summary(bank))
cat("\n")

## 5. Missing values (used)
cat("Missing values per column:\n")
print(colSums(is.na(bank)))
cat("\n")

## 6. Class balance for target (used)
cat("Distribution of Personal.Loan:\n")
loan_counts <- table(bank$Personal.Loan)
print(loan_counts)
cat("\n")

cat("Proportion of Personal.Loan:\n")
print(round(prop.table(loan_counts), 4))
cat("\n")

# 7 Data Cleaning
bank$Experience[bank$Experience < 0] <- 0
bank$ZIP.Code <- NULL

## =========================
## Simple visualisations
## =========================

## Save plots to a folder
if (!dir.exists("outputs")) dir.create("outputs")

## 1. Bar plot of target variable
png("outputs/personal_loan_barplot.png", width = 800, height = 600)
barplot(
  loan_counts,
  main = "Distribution of Personal Loan Acceptance",
  ylab = "Count",
  xlab = "Personal Loan",
  col = c("grey70", "steelblue")
)
dev.off()

## 2. Histograms for key numeric variables
png("outputs/numeric_histograms.png", width = 1200, height = 900)
par(mfrow = c(2, 3), mar = c(4, 4, 3, 1))

hist(bank$Age, main = "Age", xlab = "Age", col = "grey80", border = "white")
hist(bank$Experience, main = "Experience", xlab = "Experience", col = "grey80", border = "white")
hist(bank$Income, main = "Income", xlab = "Income ($000)", col = "grey80", border = "white")
hist(bank$Family, main = "Family", xlab = "Family Size", col = "grey80", border = "white")
hist(bank$CCAvg, main = "CCAvg", xlab = "Monthly Credit Card Spend ($000)", col = "grey80", border = "white")
hist(bank$Mortgage, main = "Mortgage", xlab = "Mortgage ($000)", col = "grey80", border = "white")

dev.off()

## 3. Boxplots of numeric predictors by target
png("outputs/boxplots_by_personal_loan.png", width = 1200, height = 900)
par(mfrow = c(2, 3), mar = c(4, 4, 3, 1))

boxplot(Age ~ Personal.Loan, data = bank,
        main = "Age by Personal Loan", xlab = "Personal Loan", ylab = "Age",
        col = c("grey80", "lightblue"))

boxplot(Experience ~ Personal.Loan, data = bank,
        main = "Experience by PMortgage

Mortgage values are highly skewed, with a large proportion of zero values, as confirmed by the median of zero in the numerical summary and the histogram. However, the boxplot shows that customers who accepted the loan tend to have higher mortgage values overall, suggesting some predictive relevance.

The scatter plot of Income versus Mortgage also reveals a positive relationship, indicating that higher-income individuals tend to have larger mortgages.rsonal Loan", xlab = "Personal Loan", ylab = "Experience",
        col = c("grey80", "lightblue"))

boxplot(Income ~ Personal.Loan, data = bank,
        main = "Income by Personal Loan", xlab = "Personal Loan", ylab = "Income ($000)",
        col = c("grey80", "lightblue"))

boxplot(Family ~ Personal.Loan, data = bank,
        main = "Family by Personal Loan", xlab = "Personal Loan", ylab = "Family Size",
        col = c("grey80", "lightblue"))

boxplot(CCAvg ~ Personal.Loan, data = bank,
        main = "CCAvg by Personal Loan", xlab = "Personal Loan", ylab = "CCAvg ($000)",
        col = c("grey80", "lightblue"))

boxplot(Mortgage ~ Personal.Loan, data = bank,
        main = "Mortgage by Personal Loan", xlab = "Personal Loan", ylab = "Mortgage ($000)",
        col = c("grey80", "lightblue"))

dev.off()

## 4. Bar plots for categorical predictors against target
png("outputs/categorical_barplots.png", width = 1200, height = 900)
par(mfrow = c(2, 3), mar = c(5, 4, 3, 1))

plot(table(bank$Education, bank$Personal.Loan),
     main = "Education vs Personal Loan",
     xlab = "Education", ylab = "Count",
     col = c("grey70", "steelblue"), beside = TRUE, legend = TRUE)

plot(table(bank$Securities.Account, bank$Personal.Loan),
     main = "Securities Account vs Personal Loan",
     xlab = "Securities Account", ylab = "Count",
     col = c("grey70", "steelblue"), beside = TRUE, legend = TRUE)

plot(table(bank$CD.Account, bank$Personal.Loan),
     main = "CD Account vs Personal Loan",
     xlab = "CD Account", ylab = "Count",
     col = c("grey70", "steelblue"), beside = TRUE, legend = TRUE)

plot(table(bank$Online, bank$Personal.Loan),
     main = "Online vs Personal Loan",
     xlab = "Online Banking", ylab = "Count",
     col = c("grey70", "steelblue"), beside = TRUE, legend = TRUE)

plot(table(bank$CreditCard, bank$Personal.Loan),
     main = "Credit Card vs Personal Loan",
     xlab = "Credit Card", ylab = "Count",
     col = c("grey70", "steelblue"), beside = TRUE, legend = TRUE)

## Optional: Family can also be shown as grouped counts
plot(table(bank$Family, bank$Personal.Loan),
     main = "Family Size vs Personal Loan",
     xlab = "Family Size", ylab = "Count",
     col = c("grey70", "steelblue"), beside = TRUE, legend = TRUE)

dev.off()

## 5. Scatterplots for selected numeric relationships, coloured by target
png("outputs/scatterplots.png", width = 1200, height = 900)
par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))

loan_col <- ifelse(bank$Personal.Loan == "Yes", "steelblue", "grey70")

plot(bank$Income, bank$CCAvg,
     col = loan_col, pch = 19,
     xlab = "Income ($000)", ylab = "CCAvg ($000)",
     main = "Income vs CCAvg")

plot(bank$Income, bank$Mortgage,
     col = loan_col, pch = 19,
     xlab = "Income ($000)", ylab = "Mortgage ($000)",
     main = "Income vs Mortgage")

plot(bank$Age, bank$Experience,
     col = loan_col, pch = 19,
     xlab = "Age", ylab = "Experience",
     main = "Age vs Experience")

plot(bank$Income, as.numeric(bank$Personal.Loan) - 1,
     col = loan_col, pch = 19,
     xlab = "Income ($000)", ylab = "Personal Loan (0 = No, 1 = Yes)",
     main = "Income vs Personal Loan")

dev.off()

cat("Plots saved in the 'outputs' folder.\n")